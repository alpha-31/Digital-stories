
// generate the controllers and actions for the comments routes 


exports.postComment = async (req, res) => {
    console.log("For posting a comment")
}

exports.getAllComments = async (req, res) => {

}

exports.deleteComment = async (req, res) => {

    console.log("For deleting a comment")
}

exports.updateComment = async (req, res) => {

}

exports.getComment = async (req, res) => {
    console.log("For getting a single comment")


}

exports.getCommentsByPostId = async (req, res) => {
    console.log("For getting comments by post id")
}

exports.getCommentsByUserId = async (req, res) => {
    console.log("For getting comments by user id")
}


    
